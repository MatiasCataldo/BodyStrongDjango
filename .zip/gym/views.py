from django.shortcuts import render

# Create your views here.
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.admin.views.decorators import staff_member_required
from .models import TeamMember, MembershipPlan

def home(request):
    return render(request, 'gym/home.html')

@login_required
def profile(request):
    return render(request, 'profile.html', {'user': request.user})

@staff_member_required
def admin_panel(request):
    members = TeamMember.objects.filter(is_active=True)
    plans = MembershipPlan.objects.all()
    return render(request, 'admin_panel.html', {
        'members': members,
        'plans': plans
    })